
public @interface webservlet {

}
